import Scripts from './Scripts.js';
import Nav from './nav.js'

function fitness() {
    return (
        <body>
            <Scripts/>
            <Nav/>
            <div class="container-fluid padding">
                <div class="row padding">
                    <div class="col-lg-12">
                        <h2>Fitness score:</h2>
                    </div>
                </div>
                <hr class="my-4"/>
            </div>
            <h1> Fitness goal complete:</h1>
            <h1 id="ResponseText"></h1>
            <input id="InputBox" type="text" placeholder="Type complete fitness goal" onkeydown="IsEnter()" autofocus/>
                <script src="Logic.js"></script>
                <div class="container-fluid padding">
                    <div class="row padding">
                        <div class="col-lg-12">
                            <h2>Fitness goals:</h2>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Fitness goal</th>
                                <th scope="col">Fitness score gainable</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>do 20 pushups</td>
                                <td>20</td>

                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>do 1 pullup</td>
                                <td>20</td>

                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td>eat 20 fruits in the week</td>
                                <td>20</td>

                            </tr>
                        </tbody>
                    </table>
                    <hr class="my-4" />
                </div>
        </body>
    );
}

export default fitness;