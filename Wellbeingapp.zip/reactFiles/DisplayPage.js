import Scripts from './Scripts.js';
import Nav from './Nav.js';

function Displaypage() {
    return (
        <body>
            <Scripts />
            <Nav />

            <div id="slides" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#slides" data-slide-to="0" class="active"></li>
                    <li data-target="#slides" data-slide-to="1" ></li>
                    <li data-target="#slides" data-slide-to="2" ></li>

                </ul>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <a href="Fitness.html"><img src="images/Fitness.jpeg" class="img-fluid" alt="Responsive image"/></a>
                        <div class="carousel-caption">
                            <h1 class="display-2" id="h1U">Fitness </h1>
                            <button onclick="document.location='Useanyservice.html'" type="button" class="btn btn-outline-light btn-lg" ></button>

                        </div>

                    </div>
                    <div class="carousel-item">
                        <a href="Mindfulness.html"><img src="images/Mindfulness.jpeg" class="img-fluid" alt="Responsive image"/></a>
                        <div class="carousel-caption"><h1>Mindfulness</h1></div>

                    </div>
                    <div class="carousel-item">
                        <a href="Healthaudit.html"><img src="images/Healthcheck.jpeg" class="img-fluid" alt="Responsive image"/></a>
                        <div class="carousel-caption"><h1>Health audit</h1></div>

                    </div>
                </div>
            </div>


            <div class="container-fluid">
                <div class="row jumbotron">
                    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
                        <p class="lead text-center"> Choose any service or view profile or badges and achievements</p>
                    </div>
                </div>
            </div>


            <div class="container-fluid padding">
                <div class="row welcome text-center">
                    <div class="col-12">
                        <h1 class="display-4">About the App</h1>
                    </div>
                    <hr/>
                        <div class="col-12">
                            <p class="lead">Use the app and get fitter, mentally and physically.
                                You can win badges and Achievements, some achievements involve gift cards to keep you motivated to stay fit!
                            </p>
                        </div>
                </div>
            </div>
            <div class="container-fluid padding">
                <div class="row text-center padding">
                    <div class="col-xs-12 col-sm-6 col-md-4"></div>
                    <img src="amazonicon.svg"/>
                        <h3>HTML5</h3>
                        <p> Built with latest version of HTML</p>
                </div>
                <hr class="my-4"/>
            </div>


            <hr class="my-4"/>
                <div class="container-fluid padding">
                    <div class="row padding">
                        <div class="col-lg-6">
                            <h2> if you use the app</h2>
                            <p>Information about why the fitness tracking is important</p>
                            <p> information about why mindfulness is important</p>
                            <p> information about why health audit is important</p>
                            <p>information about Acheivements and badges partaking companies aswell as fitness score necessary</p>
                        </div>
                        <div class="col-lg-6">
                            <img src="images/giftcard.jpeg" class="img-fluid" alt="Responsive image"/>
                        </div>
                    </div>
                    <hr class="my-4"/>
                </div>


                <div class="container-fluid padding">
                    <div class="row welcome text-center">
                        <div class="col-12">
                            <h1 class="display-4">Get proactive</h1>
                        </div>
                    </div>
                </div>
                <div class="container-fluid padding">
                    <div class="row padding">
                        <div class="col-md-4">
                            <div class="card">
                                <a href="https://www.thegymgroup.com/?gclid=CjwKCAjwlcaRBhBYEiwAK341jdTWi6NZOHGGoRqAoEY_h6FdfdZWy51yr4a6S-EgarWf6ap-TQViZhoCy6cQAvD_BwE&gclsrc=aw.ds"><img class="card-imd-top" src="images/Thegymgrouplogo.jpeg"/></a>
                                <div class="card-body">
                                    <h4 class="card-title">TheGymGroup</h4>
                                    <p class="card-text">Get connected and workout!</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <a href="https://www.sleepcycle.com/"><img class="card-imd-top" src="images/sleepcyclelogo.jpeg"/></a>
                                <div class="card-body">
                                    <h4 class="card-title">Sleepcycle</h4>
                                    <p class="card-text">Maintain your sleep with sleep cycle.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <a href="https://www.headspace.com/"><img class="card-imd-top" src="images/headspacelogo.jpeg"/></a>
                                <div class="card-body">
                                    <h4 class="card-title">Headspace</h4>
                                    <p class="card-text">Get mentally fitter with more mental health maintenance with headspace.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container-fluid padding">
                    <div class="row text-center padding">
                        <div class="col-12">
                            <h2>Get Connected</h2>
                        </div>
                        <div class="col-12 social padding">
                            <a href="https://www.facebook.com/FDMGroup"><i class="fab fa-facebook"></i></a>
                            <a href="https://twitter.com/FDMGroup?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.linkedin.com/company/fdm-group/"><i class="fab fa-linkedin"></i></a>
                            <a href="https://www.instagram.com/fdm_group/?hl=en"><i class="fab fa-instagram"></i></a>
                        </div>

                    </div>

                </div>

        </body>
    );

}

export default Displaypage;