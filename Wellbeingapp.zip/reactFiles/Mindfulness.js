import Scripts from './Scripts.js';
import Nav from './Nav.js';

function Mindfulness() {
    return (
        <body>
            <Scripts/>
            <Nav/>
            <div id="slides" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#slides" data-slide-to="0" class="active"></li>
                    <li data-target="#slides" data-slide-to="1" ></li>

                </ul>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <a href="Chatbot.html"><img src="images/chatbotlogo.jpeg" class="img-fluid" alt="Responsive image"/></a>
                        <div class="carousel-caption">
                            <h3>Chatbot </h3>
                        </div>

                    </div>
                    <div class="carousel-item">
                        <img src="images/timetablelogo.jpeg" class="img-fluid" alt="Responsive image"/>
                            <div class="carousel-caption"><a href="Booking.html"><img src="images/timetablelogo.jpeg" class="img-fluid" alt="Responsive image"/></a>Book a counselling session</div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row jumbotron">
                    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
                        <p class="lead"> Use chatbot or book a counselling session</p>
                    </div>
                </div>
            </div>
        </body>
    );
}
export default Mindfulness;