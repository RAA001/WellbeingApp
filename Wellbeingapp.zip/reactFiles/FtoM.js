function FtoM(){
    return(
        <body>

    <section>
        <div class="container">
          <form action="https://formsubmit.co/rabiantoun99@gmail.com" method="POST">
      
            <div class="form-group">
              <label for="firstName"> First Name</label>
              <input type="text" id="firstName" name="firstName"/>
            </div>
      
            <div class="form-group">
              <label for="latsName">Last Name</label>
              <input type="text" id="lastName" name="lastName"/>
            </div>
      
            <div class="form-group">
                <label for="country">Country</label>
                <input type="country" id="country" name="country"/>
              </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" id="email" name="email"/>
            </div>
      
            <div class="form-group">
              <label for="massage">Massage</label>
              <textarea name="massage" id="massage" cols="30" rows="10"></textarea>
            </div>
      
            <button type="submit">Submit</button>
          </form>
        </div>
        <div id="status"></div>
      </section>
      <button id="BTM" onclick="document.location='Mindfulness.html'" type="button" >Back to mindfulness service</button>


    
</body>
    );
}
export default FtoM;