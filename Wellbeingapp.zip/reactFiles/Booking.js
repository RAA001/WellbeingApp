import Nav from './Nav.js';


function Booking() {
    return (
        <body>
            <Nav/>
            <div class="container-fluid padding">
                <div class="row welcome text-center">
                    <div class="col-12">
                        <h1 class="display-4">Counsellors:<p> (Pick the most suitable counsellor for you.)</p></h1>
                    </div>
                </div>
            </div>
            <div class="container-fluid padding">
                <div class="row padding">
                    <div class="col-md-4">
                        <div class="card">
                            <a href="FtoM.html"><img class="card-imd-top" src="images/profileicon1.jpeg" /></a>
                            <div class="card-body">
                                <h4 class="card-title">Counsellor 1</h4>
                                <p class="card-text">Linked to profile description</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <a href="FtoM.html"><img class="card-imd-top" src="images/profileicon1.jpeg" /></a>
                            <div class="card-body">
                                <h4 class="card-title">Counsellor 2</h4>
                                <p class="card-text">Linked to profile description</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <a href="FtoM.html"><img class="card-imd-top" src="images/profileicon1.jpeg" /></a>
                            <div class="card-body">
                                <h4 class="card-title">Counsellor 3</h4>
                                <p class="card-text">Linked to profile description</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
    )
}

export default Booking;