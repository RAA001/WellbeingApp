import React from "react";
import { Container } from "react-bootstrap"
import {Credentialpage} from "./credentialpage.jsx";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Link,
  useHistory
} from "react-router-dom";
import {Displaypage} from "./components/displaypage.jsx";
import UseAnyService from "./components/UseAnyService.jsx";
import BadgesAchievements from './components/Badges&achievements.jsx'
import Profile from './components/MProfile.jsx'
import Settings from './components/settings.js'
import Fitness from './components/fitness.jsx'
import Chatbot from './components/Chatbot.js';
import Mindfulness from './components/Mindfulness.js'
import Booking from './components/Booking.js';
import FtoM from './components/FtoM';
import Healthaudit from './components/Healthaudit.js';
export class App extends React.Component {
    render(){
      return (
          <div className="App">
              <Router>
                <Routes>
                  <Route exact path="/*" element={<Credentialpage />} />
                  <Route path="/Displaypage/*" element={<Displaypage />} />
                  <Route path='/UseAnyService/*' element={<UseAnyService/>}/>
                  <Route path="/Chatbot/*" element={<Chatbot/>} />
                  <Route path='/Badges&achievements/*' element={<BadgesAchievements/>}/>
                  <Route path='/MProfile/*' element={<Profile/>}/>
                  <Route path='/settings/*'element={<Settings/>}/>
                  <Route path="/fitness/*" element={<Fitness />}/>
                  <Route path="/chatbot/*" element={<Chatbot/>} />
                  <Route path="/mindfulness/*" element={<Mindfulness/>}/>
                  <Route path="/booking/*" element={<Booking/>} />
                  <Route path="/ftom/*" element={<FtoM/>} />
                  <Route path="/audit/*" element={<Healthaudit/>} />
                </Routes>
            </Router>
          </div>
      );
    }
}

export default App;