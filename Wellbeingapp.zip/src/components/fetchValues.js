import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebase/firebase-config.js';
import { collection } from 'firebase/firestore';

// fetching the values from the employee table of the current user logged in
async function fetchValues() {
    const employeeCollectionRef = collection(db, 'employees');
    const obj = localStorage.getItem('loggedIn?');
    const id = JSON.parse(obj).auth.currentUser.uid
    const docRef = doc(db, "employees", id);
    return await getDoc(docRef)
};
export default fetchValues;