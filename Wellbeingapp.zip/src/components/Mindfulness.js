import Scripts from './Scripts.js';
import Nav from './nav.js';
import {Link} from 'react-router-dom';
function Mindfulness() {
    return (
        <body>
            <Scripts/>
            <Nav/>
            <div id="slides" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#slides" data-slide-to="0" class="active"></li>
                    <li data-target="#slides" data-slide-to="1" ></li>

                </ul>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <a><Link to="/chatbot/*"><img src={require("../images/chatbotlogo.jpeg")} class="img-fluid" alt="Responsive image"/></Link></a>
                        <div class="carousel-caption">
                            <h3>Chatbot </h3>
                        </div>

                    </div>
                    <div class="carousel-item">
                        <a><Link to="/booking/*"><img src={require("../images/timetablelogo.jpeg")} class="img-fluid" alt="Responsive image"/></Link></a>
                            <div class="carousel-caption">Book a counselling session</div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row jumbotron">
                    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
                        <p class="lead"> Use chatbot or book a counselling session</p>
                    </div>
                </div>
            </div>
        </body>
    );
}
export default Mindfulness;