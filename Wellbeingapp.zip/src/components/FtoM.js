import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import "../css/style3.css"
import Scripts from './Scripts.js';
import Nav from './nav.js';
import {useState} from 'react';
import fetchValues from './fetchValues.js';
import {useNavigate} from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import {auth} from './firebase/firebase-config.js';
export default function FtoM() {
  const [email,setEmail] = useState("");
  const history = useNavigate();
  onAuthStateChanged(auth,user=>{
    console.log(user);
    if(!user){
        history("/");
    }
  })
  fetchValues().then((res) => {
    setEmail(res._document.data.value.mapValue.fields.email.stringValue);
  })
  return (
      <React.Fragment>	  
    <section>
        <div class="container">
          <form action={"https://formsubmit.co/ajax/"+email} method="POST">
            <div class="form-group">
              <label for="firstName"> First Name</label>
              <input type="text" id="firstName" name="firstName"/>
            </div>
      
            <div class="form-group">
              <label for="latsName">Last Name</label>
              <input type="text" id="lastName" name="lastName"/>
            </div>
      
            <div class="form-group">
                <label for="country">Country</label>
                <input type="country" id="country" name="country"/>
              </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" id="email" name="email"/>
            </div>
      
            <div class="form-group">
              <label for="message">Message</label>
              <textarea name="message" id="message" cols="30" rows="10" placeholder="Please enter preferred contact method, treatment required, timing and schedule details here "></textarea>
            </div>
            <button type="submit">Submit</button>
          </form>
        </div>
        <div id="status"></div>
      </section>
      <Link to="/Mindfulness"><button id="BTM" type="button" >Back to mindfulness service</button></Link>

      </React.Fragment>
	  
  )
}