import FDMLogo from '../HTMLFiles/images/FDMLogo.jpeg';
import {Link,useNavigate} from 'react-router-dom';
import '../css/style.css';
import {auth} from './firebase/firebase-config';
import {signOut,onAuthStateChanged} from 'firebase/auth';

function Nav() {
  const history = useNavigate();
    const signOutuser= () =>{
        signOut(auth).then(function(){
            history("/");
        })
    }
    onAuthStateChanged(auth,user=>{ 
        if(!user){
            history("/");
        }
    })
    return(
        <nav className="navbar navbar-expand-md navbar-light bg-light sticky-top">
        <div className="container-fluid">
          <a className="navbar-brand" href="#"><img src={FDMLogo} /></a>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item"><a className="nav-link" ><Link to='/Displaypage'>Home</Link></a></li>
              <li className="nav-item active"><a className="nav-link" ><Link to='/UseAnyService'>Use a service</Link></a></li>
              <li className="nav-item"><a className="nav-link" ><Link to='/Badges&Achievements'>Badges&Achievements</Link></a></li>
              <li className="nav-item"><a className="nav-link" ><Link to='/MProfile'>Profile</Link></a></li>
              <li className="nav-item"><a className="nav-link" ><Link to='/settings'>Settings</Link></a></li>
              <li class="nav-item"><a class="nav-link" onClick={() => signOutuser()}>Logout</a></li>
            </ul>
          </div>
        </div>
      </nav>
    )
}
export default Nav;