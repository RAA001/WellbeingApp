import Nav from './Nav.js';
import Scripts from './Scripts.js';

function CProfile() {
    // <script> was on line 87

    //     var edit = document.getElementById('edit');
    //     edit.innerHTML=localStorage.getItem('edit');
    //     edit.addEventListener('blur',function(){
    //         localStorage.setItem('edit', this.innerHTML)
    //     });
    // </script>
    return (
        <body>
            <Nav />
            <Scripts />
            <div class="counsellor">
                <div class="navbar navbar-expand-md navbar-light bg-light sticky-top">
                    <div class="container-fluid">
                        <a class="navbar-brand" href="#"><img src="images/appLogo.jpeg" alt="App Logo" /></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarResponsive">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"><a class="nav-link" href="CounsellorDisplaypage.html">Home</a></li>
                                <li class="nav-item"><a class="nav-link" href="Calendar.html">Timetable for counselling sessions</a></li>
                                <li class="nav-item active"><a class="nav-link" href="CProfile.html">Profile</a></li>
                                <li class="nav-item"><a class="nav-link" href="SettingsC.html">Settings</a></li>
                                <li class="nav-item"><a class="nav-link" href="#">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <table class="mainTable">
                    <tr>
                        <td class='tableCell'>
                            <div class="photo">
                                <img src="images/biopicimg.jpg" alt="Profile" class="profileLogo" />
                                <h2>John Doe</h2>
                                <p>Senior Programmer Analyst</p>
                                <p>London, UK</p>
                            </div>
                        </td>
                        <td class='tableCell'>
                            <div class="info">
                                <table>
                                    <tr>
                                        <td class="boldText">Full Name</td><td class="infoText">John Doe</td>
                                    </tr>
                                    <tr>
                                        <td class="boldText">Email</td><td class="infoText">johndoe@gmail.com</td>
                                    </tr>
                                    <tr>
                                        <td class="boldText">Phone</td><td class="infoText">044123456789</td>
                                    </tr>
                                    <tr>
                                        <td class="boldText">Mobile</td><td class="infoText">044123456789m</td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td class='tableCell'>
                            <div class="social">
                                <table>
                                    <tr>
                                        <td class="boldText">Website</td><td class="infoText">www.johndoe.com</td>
                                    </tr>
                                    <tr>
                                        <td class="boldText">GitHub</td><td class="infoText">github/johndoe</td>
                                    </tr>
                                    <tr>
                                        <td class="boldText">Twitter</td><td class="infoText">twitter/johndoe</td>
                                    </tr>
                                    <tr>
                                        <td class="boldText">Instagram</td><td class="infoText">instagram/johndoe</td>
                                    </tr>
                                    <tr>
                                        <td class="boldText">Facebook</td><td class="infoText">facebook/johndoe</td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                        <td class='tableCell'>
                            <div class="info">
                                <h1>Description</h1>
                                <div id="edit" contenteditable="true"> </div>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </body>
    );

}

export default CProfile;