import fetchValues from "./fetchValues";

async function getPicture() {
    console.log("Loading picture...");
    return await fetchValues()
        .then(function(data) {
            console.log(data)
            const fields = data._document.data.value.mapValue.fields;
            console.log(fields.image.stringify, "fields.image.stringify");
        })
        .catch((err) => { console.log(err) })

}

export default getPicture;