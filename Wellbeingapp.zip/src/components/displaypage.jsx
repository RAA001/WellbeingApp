// import 'bootstrap/dist/css/bootstrap.min.css';
// import '../css/style.css';
import {React,useEffect,useState} from 'react';
import Nav from './nav.js';
import Scripts from './Scripts.js';
import {Link,useNavigate} from 'react-router-dom';
import fetchValues from './fetchValues.js';
import {auth} from './firebase/firebase-config.js';
import {onAuthStateChanged} from 'firebase/auth';
export function Displaypage(){
    const history = useNavigate();
    onAuthStateChanged(auth,user=>{
        if(!user){
            history("/");
        }
    })
    useEffect(() => {
        fetchValues()
        .then((values) =>{
            const fields = values._document.data.value.mapValue.fields;
            localStorage.setItem('userFields',JSON.stringify(fields));
            console.log("local storage set");
        })
        .catch((err) =>console.log(err));
    },[]);

    return(
        <body>
            <Nav/>
            <Scripts/>
        <div id="slides" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators">
                <li data-target="#slides" data-slide-to="0" class="active"></li>
                <li data-target="#slides" data-slide-to="1" ></li>
                <li data-target="#slides" data-slide-to="2" ></li>
            </ul>
            {/* These need to be sorted out because right now none of them are visible besides fitness + no animations */}
            <div class="carousel-inner">
                <div class="carousel-item active">
                   <Link to="/fitness/*"><img src={require("../HTMLFiles/images/fitness.jpeg")} class="img-fluid" alt="Responsive image"/></Link>
                    <div class="carousel-caption">
                        <h1 class="display-2" id="h1U">Fitness </h1>
                        <Link to="/fitness/*"><button type="button" class="btn btn-outline-light btn-lg" ></button></Link>
                    </div>
                </div>
                <div class="carousel-item">
                    <Link to="/mindfulness/*"><img src={require("../HTMLFiles/images/Mindfulness.jpeg")} class="img-fluid" alt="Responsive image"/></Link>
                    <div class="carousel-caption"><h1>Mindfulness</h1></div>
                    {/* <!-- 1600x1200--> */}
                </div>
                <div class="carousel-item">
                    <Link to="/audit/*"><img src={require("../HTMLFiles/images/Healthcheck.jpeg")} class="img-fluid" alt="Responsive image"/></Link>
                    <div class="carousel-caption"><h1>Health audit</h1></div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row jumbotron">
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
                    <p class="lead text-center"> Choose any service or view profile or badges and achievements</p>
                </div>
            </div>
        </div>
        {/* <!--Welcome Section--> */}
        <div class="container-fluid padding">
            <div class="row welcome text-center">
                <div class="col-12">
                    <h1 class="display-4">About the App</h1>
                </div>
                <hr/>
                <div class="col-12">
                    <p class="lead">Use the app and get fitter, mentally and physically.
                        You can win badges and Achievements, some achievements involve gift cards to keep you motivated to stay fit!
                    </p>
                </div>
            </div>
        </div>
        {/* <!-- Why use the app--> */}
        <hr class="my-4"/>
        <div class="container-fluid padding">
        <div class="row padding">
            <div class="col-lg-6">
                <h2> if you use the app</h2>
                <p>Information about why the fitness tracking is important</p>
                <p> information about why mindfulness is important</p>
                <p> information about why health audit is important</p>
                <p>information about Achievements and badges partaking companies aswell as fitness score necessary</p>
            </div>
            <div class="col-lg-6">
                <img src={require("../HTMLFiles/images/giftcard.jpeg")} class="img-fluid" alt="Responsive image"/>
            </div>
        </div>
        <hr class="my-4"/>
        </div>
        {/*Get connected(either gyms or advertisements for other wellbeing apps) */}
        <div class="container-fluid padding">
            <div class="row welcome text-center">
                <div class="col-12">
                    <h1 class="display-4">Get proactive</h1>
                </div>
            </div>
        </div>
        <div class="container-fluid padding">
            <div class="row padding">
                <div class="col-md-4">
                    <div class="card">
                        <a href="https://www.thegymgroup.com/?gclid=CjwKCAjwlcaRBhBYEiwAK341jdTWi6NZOHGGoRqAoEY_h6FdfdZWy51yr4a6S-EgarWf6ap-TQViZhoCy6cQAvD_BwE&gclsrc=aw.ds"><img class="card-imd-top" src={require("../HTMLFiles/images/Thegymgrouplogo.jpeg")}/></a>
                        <div class="card-body">
                            <h4 class="card-title">TheGymGroup</h4>
                            <p class="card-text">Get connected and workout!</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <a href="https://www.sleepcycle.com/"><img class="card-imd-top" src={require("../HTMLFiles/images/sleepcyclelogo.jpeg")}/></a>
                        <div class="card-body">
                            <h4 class="card-title">Sleepcycle</h4>
                            <p class="card-text">Maintain your sleep with sleep cycle.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <a href="https://www.headspace.com/"><img class="card-imd-top" src={require("../HTMLFiles/images/headspacelogo.jpeg")}/></a>
                        <div class="card-body">
                            <h4 class="card-title">Headspace</h4>
                            <p class="card-text">Get mentally fitter with more mental health maintenance with headspace.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid padding">
            <div class="row text-center padding">
                <div class="col-12">
                    <h2>Get Connected</h2>
                    <div class="col-12 social padding">
                        <a href="https://www.facebook.com/FDMGroup"><i class="fab fa-facebook"></i></a>
                        <a href="https://twitter.com/FDMGroup?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.linkedin.com/company/fdm-group/"><i class="fab fa-linkedin"></i></a>
                        <a href="https://www.instagram.com/fdm_group/?hl=en"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <footer>
                <div class="container-fluid padding">
                    <div class="row text-center">
                        <div class="col-md-4">
                            <img src={require("../HTMLFiles/images/FDMLogo(1).jpeg")}  class="img-fluid" alt="Responsive image"/>
                            <hr class="light"/>
                            <p>System administrator</p>
                            <p> Email</p>
                            <p> contact number</p>
                        </div>
                        <div class="col-md-4">
                            <hr class="light"></hr>
                            <h5>Hours of availability</h5>
                            <hr class="light"/>
                            <p>Monday-Friday 9am-5pm</p>
                            <p>Saturday: 10am-4pm</p>
                            <p>Sunday: Unavailable</p>
                        </div>
                        <div class="col-md-4">
                            <hr class="light"></hr>
                            <h5>Copyright</h5>
                            <hr class="light"></hr>
                            <p>Date of creation</p>
                            <p>Date last modified</p>
                            <p>Time period of updates</p>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
        </body>
    );
}
