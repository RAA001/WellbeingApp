import Scripts from './Scripts.js';
import Nav from './nav.js';
import {
    BrowserRouter as Router,
    Routes,
    Route,
    Navigate,
    Link,
    useHistory
  } from "react-router-dom";
export function UseAnyService() {
    return (
        <body>
            <Scripts />
            <Nav />
            <div id="slides" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#slides" data-slide-to="0" class="active"></li>
                    <li data-target="#slides" data-slide-to="1" ></li>
                    <li data-target="#slides" data-slide-to="2" ></li>
                </ul>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <Link to="/fitness/*"><img src={require("../HTMLFiles/images/fitness.jpeg")} class="img-fluid" alt="Responsive image"/></Link>
                        <div class="carousel-caption">
                            <h1 class="display-2" id="h1U">Fitness </h1>
                            <button type="button" class="btn btn-outline-light btn-lg" ></button>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <a><Link to="/mindfulness/*"><img src={require("../HTMLFiles/images/Mindfulness.jpeg")} class="img-fluid" alt="Responsive image"/></Link></a>
                        <div class="carousel-caption"><h1>Mindfulness</h1></div>

                    </div>
                    <div class="carousel-item">
                        <a><Link to="/audit/*"><img src={require("../HTMLFiles/images/Healthcheck.jpeg")} class="img-fluid" alt="Responsive image"/></Link></a>
                        <div class="carousel-caption"><h1>Health audit</h1></div>

                    </div>
                </div>
            </div>


            <div class="container-fluid">
                <div class="row jumbotron">
                    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
                        <p class="lead"> Choose any service or view profile or badges and achievements</p>
                    </div>
                </div>
            </div>
        </body>

    );
}

export default UseAnyService;