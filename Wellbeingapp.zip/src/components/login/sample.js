import react from 'react';


const Sample = () => {
    return (
        <div>Sample</div>)
}

export default Sample;