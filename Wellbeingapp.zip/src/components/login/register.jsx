import React from "react";
import loginImg from "../../login.svg";
import { db, auth } from "../firebase/firebase-config";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { collection, addDoc, setDoc, doc } from 'firebase/firestore'

export class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "",
            email: "",
            password: "",
            role: "User",
        }
    }

    handleRegister = async (event) => {
        console.log("Registering");
        const { name, email, password, role } = this.state;
        console.log(name==="", email, password, role);
        if (name == "" | email == "" || password == "" || role == "") {
            alert("Please fill all the fields");
        }else{

            try {
                const user = await createUserWithEmailAndPassword(auth, email, password);
                const usersCollectionRef = doc(db, "employees", user.user.uid);
                console.log("User created", usersCollectionRef);
                await setDoc(usersCollectionRef, {
                    name: name, email: email, role: role, achievementsEarned: 0, achievementsEarnedArr:
                        ["Arms bronze",
                            "Arms silver",
                            "Arms gold",
                            "Plank challenge bronze"],
                    badgesEarned: 0, userID: user.user.uid, badgesEarnedArr:
                        ["Monthly plank Challenge",
                            "HIIT Workout",
                            "Monthly stamina workout",
                            "Completed lower boddy challenge 3 times"], counsellorAssigned: "", fitnessScore: 0, image: ""
                });
                alert("Account created successfully");
            } catch (error) {
                switch (error.code) {
                    case 'auth/email-already-in-use':
                        alert(`Email address ${this.state.email} already in use.`);
                        break;
                    case 'auth/invalid-email':
                        alert(`Email address ${this.state.email} is invalid.`);
                        break;
                    case 'auth/operation-not-allowed':
                        alert(`Error during sign up.`);
                        break;
                    case 'auth/weak-password':
                        alert('Password is not strong enough. Add additional characters including special characters and numbers.');
                        break;
                    default:
                        console.log(error.message);
                        break;
                }
            }
        }
    }

    render() {
        return (
            <div className="base-container"
                ref={this.props.containerRef} >
                <div className="header" > Register </div>
                <div className="content" >
                    <div className="image" >
                        <img src={loginImg} />
                    </div>
                    <form >
                        <div className="form" >
                            <div className="form-group" >
                                <label htmlFor="name" > Full Name </label>
                                <input type="text"
                                    name="name"
                                    placeholder="Name and Surname"
                                    required
                                    onChange={(event) => { this.setState({ name: event.target.value }) }}
                                />
                            </div>
                            <div className="form-group" >
                                <label htmlFor="email" > Email </label>
                                <input type="text"
                                    name="email"
                                    placeholder="Email"
                                    required
                                    onChange={(event) => { this.setState({ email: event.target.value }) }}
                                />
                            </div>
                            <div className="form-group" >
                                <label htmlFor="password" > Password </label>
                                <input type="password"
                                    name="password"
                                    placeholder="Password"
                                    required
                                    onChange={(event) => { this.setState({ password: event.target.value }) }}
                                />
                            </div>
                            <div className="roles" >
                                <label
                                    for="role" > What are you registering as ?</label>
                                <select name="professions"
                                    id="professions"
                                    required
                                    onChange={(event) => { this.setState({ role: event.target.value }) }}>
                                    <option value="User" > User </option>
                                    <option value="Admin" > Admin </option>
                                    <option value="Consultant" > FDM Consultant </option>
                                </select>
                            </div>

                        </div>
                    <button class="btn" onClick={this.handleRegister}> Register </button>
                    </form>
                </div>
            </div>
        );
    }
}