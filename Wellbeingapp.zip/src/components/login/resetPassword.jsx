import React from "react";
import loginImg from "../../login.svg";
import { auth } from '../../firebase-config';
import { signInWithEmailAndPassword , sendPasswordResetEmail} from 'firebase/auth';


export class Login extends React.Component {
    constructor(props) {
        super(props);
        this.props = {
            email: ""
        }
    }

    

    render() {
        return (
            <div className="base-container"
                ref={this.props.containerRef} >
                <div className="header" > Reset Password </div>
            </div>

        );
    }
}