import React, {useState} from "react";
import loginImg from "../../login.svg";
import { auth,db } from '../firebase/firebase-config';
import { signInWithEmailAndPassword, sendPasswordResetEmail, onAuthStateChanged } from 'firebase/auth';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Link,
  useNavigate
} from "react-router-dom";

export function Login() {
    const [email, setEmail] = useState("");
    const [password,setPassword] = useState("");
    const history = useNavigate();
    onAuthStateChanged(auth,user=>{
        if(user){
            history("/Displaypage/*")    
        }
    })
    const handleLogin = async (emailval,passval,e) => {
        e.preventDefault();
        console.log("Logging in");
        setEmail(emailval);
        setPassword(passval);
        signInWithEmailAndPassword(auth, email, password).then(function(user){
            console.log(user); 
            const obj = {
                        auth:auth, 
                        email:email, 
                        bool:true}
            localStorage.setItem('loggedIn?', JSON.stringify(obj));
            history("/displaypage");
        }).catch(function(error){
            if(error.code == 'auth/wrong-password'){
                alert("You have entered an incorrect password. Please try again")
            }
            else{
                alert(error.message);
            }
        });
        // try {
        //     await signInWithEmailAndPassword(auth, email, password);
        //     const obj = {
        //         auth:auth, 
        //         email:email, 
        //         bool:true}
        //     localStorage.setItem('loggedIn?', JSON.stringify(obj));
        //     // let navigate = useNavigate();
        //     // navigate('./sample') help idk why this isnt working

        //     alert("Logged in");
        // } catch (error) {
        //     console.log(error);
        // }
        // auth().onAuthStateChanged(user=>{ 
        //     console.log(user);
        //     if(user){
        //         window.location = "./src/HTMLFiles/Displaypage.html"
        //     }
        // });
    }


    const handleReset = async (emailval,e) => {
        e.preventDefault();
        console.log("Resetting password");
        setEmail(emailval);
        try {
            await sendPasswordResetEmail(auth, email);
            alert("Password reset email sent");
        } catch (error) {
            alert("Error occured. Please try again.")
        }
    }
    return (
        <div className="base-container">
            <div className="header" > Login </div>
            <div className="content" >
                <div className="image" >
                    <img src={loginImg} />
                </div>
                <form >
                    <div className="form" >
                        <div className="form-group" >
                            <label htmlFor="email" > Email </label>
                            <input type="text"
                                className="email"
                                placeholder="Email"
                                required
                                onChange={(event) => setEmail(event.target.value) }
                            />
                        </div>
                        <div className="form-group" >
                            <label htmlFor="password" > Password </label>
                            <input type="password"
                                className="password"
                                placeholder="Password"
                                required
                                onChange={(event) => setPassword(event.target.value )}
                            />
                        </div>
                    </div>
                    <button class="btn" onClick={(e) => handleLogin(document.getElementsByClassName("email")[0].value,document.getElementsByClassName("password")[0].value,e)}> Login </button>
                    <button class="btn" onClick={(e) => handleReset(document.getElementsByClassName("email")[0].value,e)}> Forgot Password </button>
                </form>
            </div>
        </div>
    );
}