// function to check if the user has logged in
// we set the local storage once the user has logged in and give it the email, auth obj from firebase and a boolean value (not sure if needed rn)
// we call this function on every page (or just the main landing page) to check if the user has logged in and if they are allowed access to the page

export const checkLogin = () => {
    const obj = localStorage.getItem('loggedIn?');
    if (obj) {
        return true;
    }
    return false
}