import Nav from './nav.js';
import Scripts from './Scripts.js';
import { Helmet } from 'react-helmet';
import profileIcon from '../HTMLFiles/images/profileicon.jpeg';
import bioPic from '../images/biopicimg.jpg';
import '../css/style(s).css';
import { useState, useEffect } from 'react';
import { db } from './firebase/firebase-config.js';
import { collection, updateDoc, doc } from 'firebase/firestore';
import { getAuth, updateEmail, updatePassword, reauthenticateWithCredential, EmailAuthProvider, signInWithEmailAndPassword } from 'firebase/auth';
import fetchValues from './fetchValues.js';

export function Settings() {

    const [emailCheck, setCheckEmail] = useState("");
    const [passwordCheck, setCheckPassword] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [reauthenticateUser, setReauthenticate] = useState(false);
    const [url, setURL] = useState("");
    const [imageURL, setImage] = useState("")
    const [user, setUser] = useState("");

    const auth = getAuth();

    const reauthenticate = (currentPassword) => {
        var user = auth.currentUser;
        var cred = EmailAuthProvider.credential(user.email, currentPassword);
        return reauthenticateWithCredential(user, cred);
    }

    const handleURLChange = async () => {
        const obj = localStorage.getItem('loggedIn?');
        const id = JSON.parse(obj).auth.currentUser.uid
        const docRef = doc(db, "employees", id);
        await updateDoc(docRef, {
            image: url
        }).then(() => { 
            console.log("success") 
            window.location.reload(false);
        }).catch((err) => {
             console.log(err) 
            });
    }

    const handleEmailChange = async () => {
        reauthenticate(passwordCheck).then((user) => {
            var user = auth.currentUser;
            fetchValues().then((res) => {
                if (user.email != email) {
                    updateEmail(user, email).then(() => {
                        res._document.data.value.mapValue.fields.email.stringValue = email;
                        updateEmailDoc();
                        alert("Email changed")
                        // window.location.reload(false);
                    })
                }

                else {
                    alert("Email is already set")
                    window.location.reload(false);
                }
            }).catch((err) => {
                switch (err.code) {
                    case "auth/invalid-email":
                        alert("Invalid email entered");
                    case "auth/email-already-in-use":
                        alert("Email already in use");
                    case "auth/requires-recent-login":
                        alert("Please login again")
                }
            })
        }).catch((error) => {
            console.log(error);
        })
    }

    const updateEmailDoc = async () => {
        const obj = localStorage.getItem('loggedIn?');
        const id = JSON.parse(obj).auth.currentUser.uid
        const docRef = doc(db, "employees", id);
        await updateDoc(docRef, {
            email: email
        }).then(() => { console.log("success") }).catch((err) => { console.log(err) });
    }

    const handlePasswordChange = async () => {
        reauthenticate(passwordCheck).then((user) => {
            var user = auth.currentUser;
            console.log(user);
            signInWithEmailAndPassword(auth, email, password).then(() => {alert("You have entered the same password as before!")})
            .catch((error)=>{
                updatePassword(user, password)
                    .then(() => {
                        alert("Password updated");
                })
            })

        })
    }

    const login = async () => {
        signInWithEmailAndPassword(auth, emailCheck, passwordCheck).then(function (user) {
            setReauthenticate(true)
        }).catch(function (error) {
            if(error.code == 'auth/wrong-password'){
                alert("You have entered an incorrect password. Please try again")
            }
            else{
                alert(error.message);
            }
    })}

    useEffect(() => {
        fetchValues()
            .then((values) => {
                setImage(values._document.data.value.mapValue.fields.image.stringValue)
                console.log("image url set")
                console.log(imageURL)
            })
            .catch((err) => { console.log(err) });
        const fields = localStorage.getItem('userFields');
        const parsedFields = JSON.parse(fields);
        const user = parsedFields.name.stringValue;
        setUser(user);
    })

    return (
        <body>
            <Scripts />
            <Nav />
            <div className="profile-pic-div">
                <div className="text-center">
                    {imageURL === "" ? (
                        <p>No Image</p>
                    ) : (
                        <img src={imageURL} alt="Profile" className="profileLogo" />
                    )}
                </div>
                
            </div>
            <Helmet>
                <script src="code.js"></script>
            </Helmet>
            
            {reauthenticateUser === false ? (
                <div className="login-div">
                    <p>You must login again to change password or email</p>
                    <div className="mainsec">
                        <div className="mainsec">
                            <label for='email'>Email</label>
                            <br/>
                            <input className="text-box" placeholder="Email" type="text" id='email' name='email' required onChange={(event) => { setCheckEmail(event.target.value) }} />
                        </div>
                        <div className="mainsec">
                            <label for='password'>Password</label>
                            <br/>
                            <input className="text-box" placeholder="Password" type="password" id='password' name='password' required onChange={(event) => { setCheckPassword(event.target.value) }} />
                        </div>
                        <button className="btn" onClick={() => { login() }}>Login</button>
                    </div>
                </div>
            ) : (
                <div className="mainsec">
                    
                    <h1 className="head">Welcome {user}</h1>
                    <h1 className="opt">You have the following options:</h1>
                    <h2 className="user">Change Profile Picture</h2>
                    <div className="userform">
                        <input placeholder="URL" className="text-box" type="url" id="url" onChange={(event) => { setURL(event.target.value) }} />
                        <br/>
                        <button className="btn" onClick={() => { handleURLChange() }}>Change profile picture</button>
                    </div>
                    <hr/>
                    <h2 className="user">Change Email</h2>
                    <div className="userform">
                        <label for="username">Old Email:</label>
                        <br/>
                        <input className="text-box" placeholder="Old Email" type="text" id="username" name="username" required /><br />
                        <label for="newuser">New Email:</label>
                        <br/>
                        <input className="text-box" placeholder="New Email" type="text" id="newuser" name="newuser" required onChange={(event) => { setEmail(event.target.value) }} /><br />
                        <button className="btn" type="submit" value="Submit" onClick={() => { handleEmailChange() }}>Submit</button>
                    </div>
                    <hr/>
                    <h2 className="pass">Change Password</h2>
                    <div className="userform">
                        <label for="New Password">New Password:</label>
                        <br/>
                        <input className="text-box" type="password" placeholder="New Password" id="newpass" name="newpass" required onChange={(event) => { setPassword(event.target.value) }} /><br />
                        <button className="btn" type="submit" value="Submit" onClick={() => { handlePasswordChange() }}>Submit</button>
                    </div>
                </div>
            )}
        </body>
    );
}

export default Settings;