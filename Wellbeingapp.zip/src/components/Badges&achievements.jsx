import Nav from './nav.js';
import Scripts from './Scripts.js';
import badgeIcon from '../HTMLFiles/images/badgeicon.jpeg';
import '../css/style(s).css';
import fetchValues from './fetchValues.js';
import { useEffect, useState } from 'react';

export function BadgesAchievements() {
    const [badgesAchievements, setBadgesAchievements] = useState([]);
    const [lenBadges, setLenBadges] = useState(0);
    useEffect(() => {
        async function getAll() {
            fetchValues()
                .then((res) => {
                    // ignore error below it still works its just a warning
                    const fields = res._document.data.value.mapValue.fields;
                    const achievementsArr = fields.achievementsEarnedArr.arrayValue.values;
                    const badgesArr = fields.badgesEarnedArr.arrayValue.values;
                    const both = achievementsArr.concat(badgesArr);
                    const lenBadges = badgesArr.length;
                    setLenBadges(lenBadges);
                    setBadgesAchievements(both);
                    for(var i=0;i<3;i++){
                        document.getElementById("badge-"+`${i+1}`).innerHTML=both[i].stringValue;
                        document.getElementById("fitness-"+`${i+1}`).innerHTML="20";
                    }
                    console.log(fields)
                    document.getElementById("fitness-score").innerHTML=fields.fitnessScore.integerValue+"/100";
                    document.getElementById("earned").innerHTML=Number(fields.badgesEarned.integerValue) + Number(fields.achievementsEarned.integerValue);
                })
                .catch((err) => { console.log(err) })
        }
        getAll();
    }, []);
    return (
        <body>
            <Scripts />
            <Nav />
            <div className="container-fluid padding">
                <div className="row padding">
                    <div className="col-lg-12">
                        <h2>Total badges and achievements earned:</h2><h2 id = "earned"></h2>
                        <h2>Avg. Fitness score:</h2><h2 id="fitness-score">0</h2>
                    </div>
                </div>
                <hr className="my-4" />
            </div>
            <div className="container-fluid padding">
                <div className="row welcome text-center">
                    <div className="col-12">
                        <h1 className="display-8">Badges and achievements:<p> (Top 3 achievements based on fitness score gained from badge or achievement)</p></h1>
                    </div>
                </div>
            </div>
            <div className="container-fluid padding">
                <div className="row padding">
                    <div className="col-md-4">
                        <div className="card">
                            <a href="#"><img className="card-imd-top" src={badgeIcon} /></a>
                            <div className="card-body">
                                <h4 className="card-title" id="badge-1">Badge or achievement</h4>
                                <p className="card-text" id="fitness-1">Fitness score gained from badge or achievement:  </p>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="card">
                            <a href="#"><img className="card-imd-top" src={badgeIcon} /></a>
                            <div className="card-body">
                                <h4 className="card-title" id="badge-2">Badge or achievement</h4>
                                <p className="card-text" id="fitness-2">Fitness score gained from badge or achievement:</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="card">
                            <a href="#"><img className="card-imd-top" src={badgeIcon} /></a>
                            <div className="card-body">
                                <h4 className="card-title" id="badge-3">Badge or achievement</h4>
                                <p className="card-text" id="fitness-3">Fitness score gained from badge or achievement:</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container-fluid padding">
                <div className="row padding">
                    <div className="col-lg-12">
                        <h2>List of all badges and achievements:</h2>
                    </div>
                </div>
                <table className="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Badge or achievment name</th>
                            <th scope="col">Fitness score gained</th>
                            <th scope="col">Type</th>
                        </tr>
                    </thead>
                    {
                        badgesAchievements.length === 0 ? (
                            <div>
                                <h1>No badges/ achievements</h1>
                            </div>
                        ) : (

                            // mapping the dictionary and passing values to other containers
                            badgesAchievements.map((achievement, index) => (
                                <tbody>
                                    <tr>
                                        <th scope="row">{index+1}</th>
                                        <td>{achievement.stringValue}</td>
                                        <td>20</td>
                                        {index < lenBadges ? (
                                            <td>Badges</td>
                                        ) : (
                                            <td>Achievements</td>
                                        )}
                                    </tr>
                                </tbody>
                            ))
                        )
                    }
                </table>
                <hr className="my-4" />
            </div>
        </body>
    )
}

export default BadgesAchievements;