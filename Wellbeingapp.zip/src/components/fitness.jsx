import Scripts from "./Scripts.js";
import Nav from "./nav.js"
import {useEffect, useState} from 'react';
import "../HTMLFiles/css/styleFit.css";
import fetchValues from './fetchValues.js';
import { db } from './firebase/firebase-config.js';
import { doc,getDoc, updateDoc } from 'firebase/firestore';
import { collection } from 'firebase/firestore';
export function Fitness() {
    let datafill= "Rest"
    let fields;
    let userID;
    useEffect(()=>{ 
        var fitnesscore = document.getElementById("score");
        window.onload = ()=>{
            fetchValues()
                .then((res) => {
                    fields = res._document.data.value.mapValue.fields;
                    userID = fields.userID.stringValue;
                    fitnesscore.innerHTML=fields.fitnessScore.integerValue+"/100";  
                })
        }
        function ClearSport(target,fitnesscore){
            fetchValues()
            .then((res) => {
                const fields1 = res._document.data.value.mapValue.fields;    
                fitnesscore.innerHTML=Number(fields1.fitnessScore.integerValue)-1+"/100"; 
                const number = Number(fields1.fitnessScore.integerValue)-1
                const getUser = doc(db,'employees',userID)
                updateDoc(getUser,{
                    fitnessScore :number
                })
                res._document.data.value.mapValue.fields.fitnessScore.integerValue=Number(fields1.fitnessScore.integerValue)-1;
                console.log(res);
                target.innerHTML=`<p>Rest</p>`
            })
        }
        document.getElementById("confirm").addEventListener('click', () =>{
        if(document.getElementById("daySelect").value!="Select day of week" && document.getElementById("sportSelect").value!="Select Exercise (1hr)"){
            const currentDay = document.getElementById("daySelect").value + 'Sport'
            const currentSport = document.getElementById("sportSelect").value
            var selected = document.getElementById(currentDay)
            if (currentSport == "Running"){
                fetchValues()
                .then((res) => {
                    fields = res._document.data.value.mapValue.fields;
                    console.log(fields);
                    userID = fields.userID.stringValue;
                    fitnesscore.innerHTML=fields.fitnessScore.integerValue+"/100";
                    selected.innerHTML = `<img src=${require('../HTMLFiles/images/run.png')} className="sportIcon" alt="Running"> Running <button type="button" onClick className="btn btn-warning btn-sm" id="`+ currentDay+ `clear">Clear</button></img>`
                    fitnesscore.innerHTML=Number(fields.fitnessScore.integerValue)+1+"/100";
                    const number = Number(fields.fitnessScore.integerValue)+1
                    const getUser = doc(db,'employees',userID)
                    updateDoc(getUser,{
                        fitnessScore :number
                    })  
                    document.getElementById(currentDay+"clear").addEventListener("click", ()=>ClearSport(selected,fitnesscore));
                })
            }
            else if (currentSport == "Swimming"){
                fetchValues()
                .then((res) => {
                    fields = res._document.data.value.mapValue.fields;
                    userID = fields.userID.stringValue;
                    fitnesscore.innerHTML=fields.fitnessScore.integerValue+"/100";  
                    selected.innerHTML = `<img src=${require("../HTMLFiles/images/swim.png")} className="sportIcon" alt="Swimming"> Swimming <button type="button" className="btn btn-warning btn-sm" id="`+ currentDay+ `clear">Clear</button></img>`
                    fitnesscore.innerHTML=Number(fields.fitnessScore.integerValue)+1+"/100";
                    const number = Number(fields.fitnessScore.integerValue)+1
                    const getUser = doc(db,'employees',userID)
                    updateDoc(getUser,{
                        fitnessScore :number
                    })
                    document.getElementById(currentDay+"clear").addEventListener("click", ()=>ClearSport(selected,fitnesscore));
                })
            }
            else if (currentSport == "Cycling"){
                fetchValues()
                .then((res) => {
                    fields = res._document.data.value.mapValue.fields;
                    userID = fields.userID.stringValue;
                    fitnesscore.innerHTML=fields.fitnessScore.integerValue+"/100";  
                    selected.innerHTML = `<img src=${require("../HTMLFiles/images/cycle.png")} className="sportIcon" alt="Cycling"> Cycling <button type="button" className="btn btn-warning btn-sm" id="`+ currentDay+ `clear">Clear</button></img>`
                    fitnesscore.innerHTML=Number(fields.fitnessScore.integerValue)+1+"/100";
                    const number = Number(fields.fitnessScore.integerValue)+1
                    const getUser = doc(db,'employees',userID)
                    updateDoc(getUser,{
                        fitnessScore :number
                    })
                    document.getElementById(currentDay+"clear").addEventListener("click", ()=>ClearSport(selected,fitnesscore));
                })
            }
            else if (currentSport == "Gym"){
                fetchValues()
                .then((res) => {
                    fields = res._document.data.value.mapValue.fields;
                    userID = fields.userID.stringValue;
                    fitnesscore.innerHTML=fields.fitnessScore.integerValue+"/100";  
                    selected.innerHTML = `<img src=${require("../HTMLFiles/images/gym.png")} className="sportIcon" alt="Gym"> Gym <button type="button" className="btn btn-warning btn-sm" id="`+ currentDay+ `clear">Clear</button></img>`
                    fitnesscore.innerHTML=Number(fields.fitnessScore.integerValue)+1+"/100";
                    const number = Number(fields.fitnessScore.integerValue)+1
                    const getUser = doc(db,'employees',userID)
                    updateDoc(getUser,{
                        fitnessScore :number
                    })
                    document.getElementById(currentDay+"clear").addEventListener("click", ()=>ClearSport(selected,fitnesscore));
                })
            }
            else if (currentSport == "Cali"){
                fetchValues()
                .then((res) => {
                    fields = res._document.data.value.mapValue.fields;
                    userID = fields.userID.stringValue;
                    fitnesscore.innerHTML=fields.fitnessScore.integerValue+"/100";  
                    selected.innerHTML = `<img src=${require("../HTMLFiles/images/cali.png")} className="sportIcon" alt="Calisthenics"> Calisthenics <button type="button" className="btn btn-warning btn-sm" id="clear">Clear</button></img>`
                    fitnesscore.innerHTML=Number(fields.fitnessScore.integerValue)+1+"/100";
                    const number = Number(fields.fitnessScore.integerValue)+1;
                    const getUser = doc(db,'employees',userID)
                    updateDoc(getUser,{
                        fitnessScore :number
                    })
                    document.getElementById("clear").addEventListener("click", ()=>ClearSport(selected,fitnesscore));
                })
            }
        }else{
            alert("Enter a day and an exercise")
        }
    })
    })
    return (
        <div>
        <Nav/>
        <Scripts/>
        <div id="mainContain">
            <h1 id="FitnessWelcome">Welcome to your fitness page!</h1>
            <div className="row align-items-center" id="GymGroupAd">
                <div className="col-3"><img src={require("../HTMLFiles/images/Thegymgrouplogo.jpeg")} alt="gymgroupad" height="200" width="200" id="GymGroupAdPic"/></div>
                <div className="col-9"><p id="GymGroupAdDesc">The Gym Group is a great network of private, widely available Gyms with a good reputation for having a range of well maintained equipment as well as a wide range of classes led by enthusiastic coaches.</p></div>
            </div>
            <div className="row align-items-center" id="GymSharkAd">
                <div className="col-3"><img src={require("../HTMLFiles/images/gymshark-logo.png")} alt="gymsharkad" height="200" width="200" id="GymSharkAdPic"/></div>
                <div className="col-9"><p id="GymSharkAdDesc">Gymshark has a wide range of good quality gym equipment and sports clothing, great for any and all kinds of exercise.</p></div>
            </div>
            <div className="row" id="fitnessHeaders">
                <div className="col align-items-center" id="SportHeader">
                    <h1
                    >Your Routine</h1>
                </div>
            </div>
            <div className="row">
                <div className="col align-items-center">
                    <h1>Avg Fitness score: </h1><h1 id="score">0/100</h1>
                </div>
            </div>
            <div className="row">
                <div className="container-fluid" id="RoutineDays">
                        <div className="row align-items-center" id="Monday">
                            <div className="col-4">Monday</div>
                            <div className="col-8" id="MondaySport" dangerouslySetInnerHTML={{__html:datafill}}></div>
                        </div>
                        <div className="row align-items-center" id="Tuesday">
                            <div className="col-4 ">Tuesday</div>
                            <div className="col-8" id="TuesdaySport" dangerouslySetInnerHTML={{__html:datafill}}></div>
                        </div>
                        <div className="row align-items-center" id="Wednesday">
                            <div className="col-4">Wednesday</div>
                            <div className="col-8 " id="WednesdaySport" dangerouslySetInnerHTML={{__html:datafill}}></div>
                        </div>
                        <div className="row align-items-center" id="Thursday">
                            <div className="col-4 ">Thursday</div>
                            <div className="col-8" id="ThursdaySport" dangerouslySetInnerHTML={{__html:datafill}}></div>
                        </div>
                        <div className="row align-items-center" id="Friday">
                            <div className="col-4">Friday</div>
                            <div className="col-8 " id="FridaySport" dangerouslySetInnerHTML={{__html:datafill}}></div>
                            </div>
                        <div className="row align-items-center" id="Saturday">
                            <div className="col-4 ">Saturday</div>
                            <div className="col-8" id="SaturdaySport" dangerouslySetInnerHTML={{__html:datafill}}></div>
                        </div>
                        <div className="row align-items-center" id="Sunday">
                            <div className="col-4">Sunday</div>
                            <div className="col-8" id="SundaySport" dangerouslySetInnerHTML={{__html:datafill}}></div>
                        </div>
                </div>
            </div>
            <div className="row">
                <div className="col">
                </div>
                <div className="row">
                    <div className="col">
                        <div>
                            <select className="form-select" aria-label="Default select example" id="daySelect">
                                <option defaultValue="Select day">Select day of week</option>
                                <option value="Monday">Monday</option>
                                <option value="Tuesday">Tuesday</option>
                                <option value="Wednesday">Wednesday</option>
                                <option value="Thursday">Thursday</option>
                                <option value="Friday">Friday</option>
                                <option value="Saturday">Saturday</option>
                                <option value="Sunday">Sunday</option>
                            </select>
                        </div>
                    </div>
                    <div className="col">
                        <div>
                            <select className="form-select" aria-label="Default select example" id="sportSelect">
                                <option selected>Select Exercise (1hr)</option>
                                <option value="Running">Running</option>
                                <option value="Swimming">Swimming</option>
                                <option value="Cycling">Cycling</option>
                                <option value="Gym">Gym</option>
                                <option value="Cali">Calisthenics</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div id="RoutineButtons"> 
                    <button type="button" className="btn btn-success" id="confirm">Confirm</button>
                </div>
            </div>
            </div>
            <footer>
                <div className="container-fluid padding">
                    <div className="row text-center">
                        <div className="col-md-4">
                            <hr className="light"/>
                            <p>System administrator</p>
                            <p> Email</p>
                            <p> contact number</p>
                        </div>
                        <div className="col-md-4">
                            <hr className="light"/>
                            <h5>Hours of availability</h5>
                            <hr className="light"/>
                            <p>Monday-Friday 9am-5pm</p>
                            <p>Saturday: 10am-4pm</p>
                            <p>Sunday: Unavailable</p>

                        </div>
                        <div className="col-md-4">
                            <hr className="light"/>
                            <h5>Copyright</h5>
                            <hr className="light"/>
                            <p>Date of creation</p>
                            <p>Date last modified</p>
                            <p>Time period of updates</p>

                        </div>
                    </div>
                </div>
            </footer>
            </div>
    );
}
export default Fitness;