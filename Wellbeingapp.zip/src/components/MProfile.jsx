import Nav from './nav.js';
import Scripts from './Scripts.js';
import "../HTMLFiles/css/Styles.css";
import {db} from './firebase/firebase-config.js';
import {collection} from 'firebase/firestore';
import {useEffect,useState} from 'react';
import fetchValues from './fetchValues.js';
import getPicture from './getPicture.js';
import bioPic from '../images/biopicimg.jpg';

export function MProfile() {
    const [user,setUser]=useState(null);
    const [email,setEmail]=useState(null);
    const [role,setRole]=useState(null);
    const [url,setURL]=useState(null);    

    window.onload = function(event){
            document.getElementById("edit").innerHTML = localStorage['edit'];
            document.getElementById("edit").addEventListener('blur',function(){
                localStorage.setItem('edit',document.getElementById("edit").innerHTML)
            })
    }
    useEffect(()=> {
        getPicture();
        async function fetchData(){
            fetchValues()
            .then((res) =>{
                const fields = res._document.data.value.mapValue.fields;
                localStorage.setItem('userFields',JSON.stringify(fields));
                const name = fields.name.stringValue;
                const email = fields.email.stringValue;
                const role = fields.role.stringValue;
                const image = fields.image.stringValue;
                setUser(name);
                setEmail(email);
                setRole(role);
                setURL(image)
            })
            .catch((err) =>console.log(err));
        }
          fetchData();
    },[])
    
    return (
        //     <script> was on line 60
        //     var edit = document.getElementById('edit');
        //     edit.innerHTML=localStorage.getItem('edit');
        //     edit.addEventListener('blur',function(){
        //         localStorage.setItem('edit',this.innerHTML);
        //     });
        // </script>

        <body>
            <Scripts />
            <Nav />
            <div className="counsellor">
                <table className="mainTable">
                    <tr>
                        <td className='tableCell'>
                            <div className="photo">
                                {url === "" ? (
                                    <img src={bioPic} alt="Profile" className="profileLogo" />
                                ):(
                                    <img src={url} alt="Profile" className="profileLogo" />
                                )}
                                
                                <h2>{user}</h2>
                                <p>Employee type: {role}</p>
                                <p>Based in : London, UK</p>
                            </div>
                        </td>
                        <td className='tableCell'>
                            <div className="info">
                                <table>
                                    <tr>
                                        <td className="boldText">Full Name</td><td className="infoText">{user}</td>
                                    </tr>
                                    <tr>
                                        <td className="boldText">Email</td><td className="infoText">{email}</td>
                                    </tr>
                                    <tr>
                                        <td className="boldText">Phone</td><td className="infoText">044123456789</td>
                                    </tr>
                                    <tr>
                                        <td className="boldText">Mobile</td><td className="infoText">044123456789</td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td className='tableCell'>
                            <div className="social">
                                <table>
                                    <tr>
                                        <td className="boldText">Website</td><td className="infoText">www.{user}.com</td>
                                    </tr>
                                    <tr>
                                        <td className="boldText">GitHub</td><td className="infoText">github/{user}</td>
                                    </tr>
                                    <tr>
                                        <td className="boldText">Twitter</td><td className="infoText">twitter/{user}</td>
                                    </tr>
                                    <tr>
                                        <td className="boldText">Instagram</td><td className="infoText">instagram/{user}</td>
                                    </tr>
                                    <tr>
                                        <td className="boldText">Facebook</td><td className="infoText">facebook/{user}</td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                        <td className='tableCell'>
                            <div className="info">
                                <h1>Description</h1>
                                <div id="edit" contentEditable={true} suppressContentEditableWarning={true}></div>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </body>
    );
}

export default MProfile;