import Scripts from './Scripts.js';
import Nav from './Nav.js';

function CounsellorDisplaypage() {
    return (
        <body>
            <Scripts />
            <Nav />
            <div id="slides" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#slides" data-slide-to="0" class="active"></li>
                    <li data-target="#slides" data-slide-to="1" ></li>
                </ul>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <a href="CProfile.html"><img src="images/profileicon.jpeg" class="img-fluid" alt="Responsive image"/></a>
                        <div class="carousel-caption">
                            <button onclick="document.location='CProfile.html'" type="button" class="btn btn-outline-light btn-lg" ></button>
                        </div>
                    </div>
                    <div class="carousel-item"><a href="Calendar.html"><img src="images/timetablelogo.jpeg" class="img-fluid" alt="Responsive image"/></a>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row jumbotron">
                    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
                        <p class="lead text-center"> Choose 'Timetable for counselling sessions' if changes need to be made to timetable of mindfulness support. Choose Profile if edits need to be made in relation to profile description</p>
                    </div>
                </div>
            </div>
        </body>
    );
}
export default CounsellorDisplaypage;