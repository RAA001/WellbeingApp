// Let's code our chatbot's logic!
function IsEnter()
{
	var TextBox_val = document.getElementById("InputBox").value; // Get all the data from the input box.

	// If enter key is pressed then only respond.
	if (TextBox_val != "")
	{
		if (event.keyCode == 13)
			main();
	}
}

function main()
{
	// the main logic will be coded here.
	var TextBox_val = document.getElementById("InputBox").value; // Get all the data from the input box.
	var ResponseText_val = document.getElementById("ResponseText"); // Get all the data from the response text.

	var FormatInput = TextBox_val.toLowerCase().trim(); // convert our given input to lowercase.
	// For example "Apple" -> "apple".

	// Let's code the Logic for chatting...
	// and like this you can add several more features to it make it really advance.
	// As i said, i will be uploading it's source code it github so just check the link in description!
	if (FormatInput.includes("hi") || FormatInput.includes("hello"))
		ResponseText_val.innerHTML = "Hello!";

	else if (FormatInput.includes("general ways to feel better.")  || FormatInput.includes("general ways to feel better") )
		ResponseText_val.innerHTML = "List of general ways to feel better: <p> Exercise";

	// Open websites!
	else if (FormatInput.includes("book a counselling session")|| FormatInput.includes("book a counselling session."))
	{
		// "https://" is important!
		ResponseText_val.innerHTML = "Opening Mindfulness service, 'Book a counselling session'";
		window.open("Useanyservice.html");
	}
	else if (FormatInput.includes("help")|| FormatInput.includes("help."))
	{
		// "https://" is important!
		ResponseText_val.innerHTML = "If you require help in relation to mental health, please seek advice from a counsellor, while answers can be given generally it is better to seek help from a counsellor as the quaity of service would be better and more effective.";
	}

	else
		ResponseText_val.innerHTML = "Sorry, I can't understand you 😔, if you require anything other than the two mindfulness services mentioned please book a counselling session for a qualitative and sufficient  service to be provided.";
}

// THANKS FOR WATCHING!!!
