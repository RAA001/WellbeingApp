// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth";
import {getFirestore} from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDya_Bwu5TSRuUGOgojBZ1xfOHmEaJ4xlg",
  authDomain: "fdm-wellbeing.firebaseapp.com",
  projectId: "fdm-wellbeing",
  storageBucket: "fdm-wellbeing.appspot.com",
  messagingSenderId: "723778864384",
  appId: "1:723778864384:web:42ab2560b2ee476d1ddfe5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);